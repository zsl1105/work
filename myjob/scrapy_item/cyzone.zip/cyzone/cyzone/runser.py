from scrapy import cmdline
name = 'run'
cmd = 'scrapy crawl {0}'.format(name)
cmdline.execute(cmd.split())